using Godot;
using System;

public partial class jogador : CharacterBody2D
{
	private AnimatedSprite2D animation;
	public Vector2 savePoint;
	public const float Speed = 300.0f;
	public const float JumpVelocity = -400.0f;
	public const int MaxJumps = 2; // Define o número máximo de pulos

	// Get the gravity from the project settings to be synced with RigidBody nodes.
	public float gravity = ProjectSettings.GetSetting("physics/2d/default_gravity").AsSingle();

	private int jumpCount; // Variável para rastrear o número de pulos realizados
	
	public void ReturnToSavePoint(){
		GlobalPosition = savePoint;
	}
	
	public void SetSavePoint(){
		savePoint = GlobalPosition;
	}
	
	public override void _Ready() {
		animation = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
		jumpCount = 0; // Inicializa o contador de pulos
	}

	public override void _PhysicsProcess(double delta)
	{
		Vector2 velocity = Velocity;
		// Get the input direction and handle the movement/deceleration.
		Vector2 direction = Input.GetVector("ui_left", "ui_right", "ui_up", "ui_down");
	
		// Add the gravity.
		if (!IsOnFloor()){
			velocity.Y += gravity * (float)delta;
			// Check if the player is in the air and changing direction.
			if (Mathf.Sign(direction.X) != Mathf.Sign(velocity.X))
			{
				velocity.X = Speed * direction.X * 0.65f; // Reduz a velocidade no ar ao alterar a direção
				if (velocity.X > 0)
				{
					animation.FlipH = true;
				}
				else
				{
					animation.FlipH = false;
				}
			}
		}
		else
		{
			velocity.X = Speed * direction.X;
			jumpCount = 0; // Reseta o contador de pulos quando o jogador tocar o chão
		}

		// Handle Jump.
		if (Input.IsActionJustPressed("ui_accept"))
		{
			if (IsOnFloor() || jumpCount < MaxJumps) // Permite o pulo se o jogador estiver no chão ou se o número máximo de pulos ainda não tiver sido atingido
			{
				velocity.Y = JumpVelocity;
				jumpCount++; // Incrementa o contador de pulos
			}
		}

		Velocity = velocity;

		if (!IsOnFloor())
		{
			animation.Play("jump");
		}
		else
		{
			if (velocity.X != 0)
			{
				animation.Play("run");
				if (velocity.X > 0)
				{
					animation.FlipH = true;
				}
				else
				{
					animation.FlipH = false;
				}
			}
			else
			{
				animation.Play("idle");
			}
		}

		MoveAndSlide();
	}
}
